# Torrentula

A minimal tool for finding open-source software and other freely
distributable torrents. It comes as a clean, windowed app (light and dark mode,
built to Apple's design guidelines) and as a text version for the terminal.
It searches two sources at the same time:

- **apibay.org**: The Pirate Bay's official JSON API
- **api.knaben.org**: a meta-search API that aggregates TPB, 1337x, Nyaa, YTS
  and other indexes

Results are merged, de-duplicated by info-hash (keeping the copy with the most
seeders), sorted by seeder count, and paged. No API keys or accounts needed.

## Install

Extract the whole zip, then run the installer for your system. That's it.

| System  | Do this                                                       |
| ------- | ------------------------------------------------------------- |
| Windows | Double-click **`Install-Windows.bat`**                        |
| macOS   | Double-click **`Install-macOS.command`**                      |
| Linux   | Run `bash Install-Linux.sh` in a terminal                     |

Everything installs just for you. No admin rights or `sudo` needed. When it
finishes, open **Torrentula** from your Start Menu / Launchpad / applications
menu. That opens the windowed app. If you prefer text, there is a **Torrentula
Terminal** entry on Windows and Linux, and a `torrentula "ubuntu 24.04"` command
on macOS and Linux.

You need Python 3.8+ at install time. On Windows the installer will fetch it for
you with winget if it's missing; on macOS/Linux it tells you what to install.

<details>
<summary>What each installer does</summary>

- **Windows**: builds `Torrentula.exe` (the app) and `TorrentulaTerminal.exe` in
  a temporary folder (takes a couple of minutes, then cleans up after itself), installs them to
  `%LOCALAPPDATA%\Programs\Torrentula`, adds a Start Menu shortcut, and lists
  it under *Settings > Apps > Installed apps*.
- **macOS**: creates a private Python environment in
  `~/Library/Application Support/Torrentula`, adds `~/Applications/Torrentula.app`
  and the `torrentula` and `torrentula-gui` commands in `~/.local/bin`.
- **Linux**: creates a private Python environment in `~/.local/share/torrentula`,
  adds `torrentula` and `torrentula-gui` commands in `~/.local/bin` and two
  application-menu entries (the app and the terminal version).

Nothing is installed system-wide. Running an installer again upgrades in place.
</details>

## Uninstall

| System  | Do this                                                                     |
| ------- | --------------------------------------------------------------------------- |
| Windows | *Settings > Apps > Installed apps > Torrentula > Uninstall*, or double-click `files\windows\Uninstall.bat` |
| macOS   | Double-click `files/macos/uninstall.command`                                |
| Linux   | `bash files/linux/uninstall.sh`                                             |

Magnet files you saved are always kept.

## Using the app

Type in the search field and press Return. Results are ranked by seeders; use the
Seeders / Size / Name control to re-sort. Click a result to open it, then:

- **Copy Magnet Link**, then paste it into your torrent client's "Add Link" /
  "Add Magnet Link" dialog
- **Open in Client** hands the link straight to your default torrent client
- **Save as File** puts a small text file in your **Downloads** folder; **Show in Folder** then reveals it there

Use the **Home** button at the top left to go back to the start screen. Press `/` to
jump to the search field, and use the arrow keys to move through results. **Show More Results** loads further pages (up to 1000 hits in total).
The app follows your system's light or dark appearance, and it closes by itself
when you close its window.

The app runs a small server that only listens on your own computer (127.0.0.1) and
opens its window with Edge, Chrome or another Chromium browser if you have one,
otherwise your default browser. Nothing is exposed to your network.

## Using the terminal version

```
Results 1-15 of 139+   (page 1 of 10+)
#        S     L      Size  Source       Name
----------------------------------------------------------------------------------------------------
1      842    31    5.7GB  PirateBay    ubuntu-24.04-desktop-amd64.iso
2      210     8    5.7GB  1337x        Ubuntu 24.04 LTS Desktop
...
```

| Key      | Action                                                                  |
| -------- | ----------------------------------------------------------------------- |
| `n`      | next page (loads more results if needed)                                |
| `p`      | previous page                                                           |
| `g 3`    | jump to page 3                                                          |
| a number | select that result (numbers are global, so #16 is the first on page 2) |
| `s`      | new search                                                              |
| `q`      | quit                                                                    |

A `+` after the totals means more results can still be loaded. The first search
loads up to about 100 hits per source; pressing `n` past the last loaded page
fetches the next batch from Knaben (up to 1000 in total). Later results are
appended, so earlier numbers never change under you. Use `-n 30` to show 30
results per page instead of 15.

After picking a result you can:

1. **Copy the magnet link to your clipboard** (recommended), then paste it into
   your torrent client's "Add Link" / "Add Magnet Link" dialog
2. **Save it as a text file** in the `magnetfiles` folder
3. Print it, to copy manually

A saved magnet file is plain text, **not** a real `.torrent` file. Use your
client's "Add Link" / "Add Magnet Link", not "Add Torrent File". Torrentula only
searches and hands you the link; it doesn't download anything itself.

In the terminal version, saved magnet files live in a `magnetfiles` folder inside the
install folder (the installer prints the exact path). Duplicate names get ` (2)`, ` (3)`...
appended, so nothing is overwritten.

## Troubleshooting

- **Windows SmartScreen warning on first launch**: expected for any app you
  built yourself rather than one signed with a paid certificate. Click *More
  info > Run anyway*.
- **macOS says the installer can't be opened**: right-click it, choose *Open*,
  then *Open* again. Or run `bash Install-macOS.command` in Terminal.
- **Linux/macOS: `torrentula` command not found**: `~/.local/bin` isn't on your
  PATH yet. Log out and back in, or use the menu / Launchpad entry.
- **Linux: "couldn't create a Python environment"**: on Debian/Ubuntu run
  `sudo apt install python3-venv`, then install again.
- **Copy-to-clipboard doesn't work on Linux**: install `xclip` (X11) or
  `wl-clipboard` (Wayland). Option 3 (print) always works.
- **A source is down or rate-limiting**: Torrentula says so and carries on with
  whatever the other source returned.
- **The window opens in a browser tab instead of its own window**: that happens
  when no Chromium-based browser is installed. It works the same; closing the tab
  quits the app.

## What's in the folder

```
Install-Windows.bat       double-click to install on Windows
Install-macOS.command     double-click to install on macOS
Install-Linux.sh          run with bash to install on Linux
files/
├── README.md             this file
├── app/                  the program itself
│   ├── torrentula_gui.py     the windowed app (server)
│   ├── torrentula_gui.html   the windowed app (interface)
│   ├── torrentula.py         search code and terminal version
│   ├── requirements.txt
│   ├── torrentula.ico    app icon (Windows)
│   ├── torrentula.png    app icon (macOS / Linux)
│   └── make_icon.py      regenerates the icons (optional, needs Pillow)
├── windows/              install.ps1, uninstall.ps1, Uninstall.bat
├── macos/                install.sh, uninstall.command
└── linux/                install.sh, uninstall.sh
```

You can also run it straight from source without installing:
`pip install -r files/app/requirements.txt`, then `python files/app/torrentula_gui.py`
for the app or `python files/app/torrentula.py` for the terminal version.
