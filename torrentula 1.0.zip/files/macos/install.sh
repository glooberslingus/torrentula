#!/usr/bin/env bash
# Torrentula installer for macOS (run by Install-macOS.command). No admin needed.
#   app + its own private Python environment -> ~/Library/Application Support/Torrentula
#   Torrentula app (Launchpad/Spotlight)      -> ~/Applications/Torrentula.app
#   `torrentula` command                       -> ~/.local/bin
set -e

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$(cd "$HERE/../app" && pwd)"
INSTALL="$HOME/Library/Application Support/Torrentula"
BIN="$HOME/.local/bin"
BUNDLE="$HOME/Applications/Torrentula.app"

say()  { printf '%s\n' "$*"; }
fail() { printf '\n%s\n' "$*" >&2; exit 1; }

say ""
say "Installing Torrentula"
say "---------------------"

[ -f "$APP/torrentula.py" ] || fail "Couldn't find files/app/torrentula.py. Please extract the whole zip first, then run the installer again."

# 1. Python ---------------------------------------------------------------
say "[1/3] Looking for Python..."
find_python() {
    local c
    for c in /opt/homebrew/bin/python3 /usr/local/bin/python3 \
             /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
             "$(command -v python3 2>/dev/null)" ; do
        [ -n "$c" ] && [ -x "$c" ] || continue
        # /usr/bin/python3 is a stub that pops up an installer dialog unless the
        # Command Line Tools are installed, so only trust it when they are.
        if [ "$c" = "/usr/bin/python3" ] && ! xcode-select -p >/dev/null 2>&1; then continue; fi
        if "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
            echo "$c"; return 0
        fi
    done
    return 1
}
PY="$(find_python || true)"
if [ -z "$PY" ] && command -v brew >/dev/null 2>&1; then
    say "      Python isn't installed. Installing it with Homebrew..."
    brew install python >/dev/null 2>&1 || true
    PY="$(find_python || true)"
fi
if [ -z "$PY" ]; then
    fail "Python 3.8 or newer wasn't found.
Install it from https://www.python.org/downloads/macos/ (or run: xcode-select --install),
then double-click Install-macOS.command again."
fi
say "      Using $PY"

# 2. Private environment --------------------------------------------------
say "[2/3] Setting up (a few seconds)..."
mkdir -p "$INSTALL/magnetfiles"
rm -rf "$INSTALL/venv"
"$PY" -m venv "$INSTALL/venv" >/dev/null 2>&1 || { rm -rf "$INSTALL/venv"; fail "Couldn't create a Python environment."; }
"$INSTALL/venv/bin/python" -m pip install --disable-pip-version-check -q -r "$APP/requirements.txt" \
    || fail "Couldn't download the dependencies. Check your internet connection and try again."

cp "$APP/torrentula.py" "$APP/torrentula_gui.py" "$APP/torrentula_gui.html" "$APP/torrentula.png" "$INSTALL/"

# 3. Launcher, command, app ----------------------------------------------
say "[3/3] Adding the Torrentula app and 'torrentula' command..."
cat > "$INSTALL/torrentula" <<LAUNCH
#!/usr/bin/env bash
export TORRENTULA_MAGNET_DIR="$INSTALL/magnetfiles"
exec "$INSTALL/venv/bin/python" "$INSTALL/torrentula.py" "\$@"
LAUNCH
chmod +x "$INSTALL/torrentula"

cat > "$INSTALL/torrentula-gui" <<LAUNCH
#!/usr/bin/env bash
export TORRENTULA_MAGNET_DIR="$INSTALL/magnetfiles"
exec "$INSTALL/venv/bin/python" "$INSTALL/torrentula_gui.py" "\$@"
LAUNCH
chmod +x "$INSTALL/torrentula-gui"

mkdir -p "$BIN"
ln -sf "$INSTALL/torrentula" "$BIN/torrentula"
ln -sf "$INSTALL/torrentula-gui" "$BIN/torrentula-gui"

# A tiny app bundle that opens the Torrentula window.
rm -rf "$BUNDLE"
mkdir -p "$BUNDLE/Contents/MacOS" "$BUNDLE/Contents/Resources"
cat > "$BUNDLE/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key><string>Torrentula</string>
    <key>CFBundleDisplayName</key><string>Torrentula</string>
    <key>CFBundleIdentifier</key><string>local.torrentula</string>
    <key>CFBundleExecutable</key><string>Torrentula</string>
    <key>CFBundleIconFile</key><string>Torrentula</string>
    <key>CFBundlePackageType</key><string>APPL</string>
    <key>CFBundleVersion</key><string>1.1.0</string>
    <key>CFBundleShortVersionString</key><string>1.1.0</string>
    <key>LSMinimumSystemVersion</key><string>10.13</string>
</dict>
</plist>
PLIST
cat > "$BUNDLE/Contents/MacOS/Torrentula" <<LAUNCHER
#!/bin/bash
exec "$INSTALL/torrentula-gui"
LAUNCHER
chmod +x "$BUNDLE/Contents/MacOS/Torrentula"

# App icon (best effort: the app works fine without it).
(
    set -e
    ICONSET="$(mktemp -d)/Torrentula.iconset"
    mkdir -p "$ICONSET"
    for s in 16 32 128 256 512; do
        sips -z $s $s "$APP/torrentula.png" --out "$ICONSET/icon_${s}x${s}.png" >/dev/null
        sips -z $((s*2)) $((s*2)) "$APP/torrentula.png" --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null
    done
    iconutil -c icns "$ICONSET" -o "$BUNDLE/Contents/Resources/Torrentula.icns"
) >/dev/null 2>&1 || true
touch "$BUNDLE"

say ""
say "Done! Torrentula is installed."
say "  Open it from Launchpad or Spotlight (search for 'Torrentula'),"
say "  Prefer text? In Terminal run:  torrentula \"ubuntu 24.04\""
say "  The app saves magnet files to your Downloads folder."
say "  (The terminal version saves them in: $INSTALL/magnetfiles)"
case ":$PATH:" in
    *":$BIN:"*) ;;
    *) say ""
       say "  Note: $BIN isn't on your PATH, so the 'torrentula' command won't work in"
       say "  Terminal until you add it. The Torrentula app works regardless." ;;
esac
say ""
say "To uninstall: double-click files/macos/uninstall.command"
