#!/usr/bin/env bash
# Removes Torrentula. Any magnet files you saved are KEPT.
INSTALL="$HOME/Library/Application Support/Torrentula"

if [ ! -d "$INSTALL" ] && [ ! -d "$HOME/Applications/Torrentula.app" ]; then
    echo "Torrentula doesn't appear to be installed."
fi

# Only remove the command if it's ours.
[ "$(readlink "$HOME/.local/bin/torrentula" 2>/dev/null)" = "$INSTALL/torrentula" ] && rm -f "$HOME/.local/bin/torrentula"
[ "$(readlink "$HOME/.local/bin/torrentula-gui" 2>/dev/null)" = "$INSTALL/torrentula-gui" ] && rm -f "$HOME/.local/bin/torrentula-gui"
rm -rf "$HOME/Applications/Torrentula.app"

if [ -d "$INSTALL" ]; then
    rm -rf "$INSTALL/venv" "$INSTALL/torrentula" "$INSTALL/torrentula-gui" "$INSTALL/torrentula.py" "$INSTALL/torrentula_gui.py" "$INSTALL/torrentula_gui.html" "$INSTALL/torrentula.png" "$INSTALL/__pycache__"
    rmdir "$INSTALL/magnetfiles" 2>/dev/null   # only succeeds if empty
    rmdir "$INSTALL" 2>/dev/null
fi

echo "Torrentula has been uninstalled."
[ -d "$INSTALL/magnetfiles" ] && echo "Your saved magnet files were left in: $INSTALL/magnetfiles"
echo
read -r -p "Press Enter to close..." _ || true
exit 0
