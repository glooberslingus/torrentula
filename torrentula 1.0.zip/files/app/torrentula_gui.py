#!/usr/bin/env python3
"""
torrentula_gui.py

The graphical version of Torrentula. It starts a tiny web server that only
listens on this computer (127.0.0.1), then opens the interface in its own
window. The search logic is shared with the terminal version (torrentula.py).

The program quits by itself shortly after its window is closed.

Usage:
    python torrentula_gui.py            # open in an app-style window
    python torrentula_gui.py --tab      # open in a normal browser tab instead
    python torrentula_gui.py --no-open  # just print the address
"""

import argparse
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# A windowed (no console) build has no stdout/stderr; make printing harmless.
if sys.stdout is None:
    sys.stdout = open(os.devnull, "w")
if sys.stderr is None:
    sys.stderr = open(os.devnull, "w")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import torrentula as core  # noqa: E402  (shared search code)

BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
HTML_PATH = os.path.join(BASE_DIR, "torrentula_gui.html")
ICON_PATH = os.path.join(BASE_DIR, "torrentula.png")

TOKEN = secrets.token_urlsafe(24)
MAX_BODY = 64 * 1024
IDLE_LIMIT = 120      # seconds without a heartbeat before quitting
BYE_GRACE = 4         # seconds to wait after the window says goodbye (a reload sends one too)


class State:
    def __init__(self):
        self.lock = threading.RLock()
        self.session = None
        self.started = time.time()
        self.last_ping = None
        self.bye_at = None
        self.saved = set()   # files this app saved; the only ones Show in Folder will reveal


STATE = State()
PORT = 0


def result_dict(index, r):
    return {
        "i": index,
        "name": r.name,
        "seeders": r.seeders,
        "leechers": r.leechers,
        "size": r.size_bytes,
        "sizeText": re.sub(r"(\d)([A-Z])", r"\1 \2", core.human_size(r.size_bytes)),
        "source": r.source,
        "magnet": r.magnet,
    }


def api_search(body):
    query = str(body.get("query", "")).strip()
    if not query:
        return {"results": [], "exhausted": True, "errors": {}}
    core.SOURCE_ERRORS.clear()
    session = core.SearchSession(query)
    session.load_initial()
    with STATE.lock:
        STATE.session = session
    return {
        "results": [result_dict(i, r) for i, r in enumerate(session.results)],
        "exhausted": session.exhausted,
        "errors": dict(core.SOURCE_ERRORS),
    }


def api_more(_body):
    with STATE.lock:
        session = STATE.session
        if session is None:
            return {"results": [], "exhausted": True, "error": False}
        core.SOURCE_ERRORS.clear()
        start = len(session.results)
        session.fetch_more()
        new = [result_dict(i, r) for i, r in enumerate(session.results) if i >= start]
        return {
            "results": new,
            "exhausted": session.exhausted,
            "error": bool(core.SOURCE_ERRORS),
        }


def downloads_dir():
    """The person's Downloads folder (falls back to the magnetfiles folder)."""
    path = None
    if sys.platform == "win32":
        try:
            import ctypes
            from ctypes import wintypes

            class GUID(ctypes.Structure):
                _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                            ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

            fid = GUID(0x374DE290, 0x123F, 0x4565,
                       (ctypes.c_ubyte * 8)(0x91, 0x64, 0x39, 0xC4, 0x92, 0x5E, 0x46, 0x7B))
            buf = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(fid), 0, None, ctypes.byref(buf)) == 0:
                path = buf.value
                ctypes.windll.ole32.CoTaskMemFree(buf)
        except Exception:
            path = None
    elif sys.platform != "darwin":
        try:
            out = subprocess.run(["xdg-user-dir", "DOWNLOAD"], capture_output=True, text=True, timeout=3).stdout.strip()
            if out and os.path.abspath(out) != os.path.expanduser("~"):
                path = out
        except (OSError, subprocess.SubprocessError):
            path = None
    if not path:
        path = os.path.join(os.path.expanduser("~"), "Downloads")
    try:
        os.makedirs(path, exist_ok=True)
        return path
    except OSError:
        return core.MAGNET_DIR


def api_save(body):
    with STATE.lock:
        session = STATE.session
        try:
            r = session.results[int(body.get("index"))]
        except (AttributeError, TypeError, ValueError, IndexError):
            return {"error": "That result is no longer available."}
    try:
        folder = downloads_dir()
        os.makedirs(folder, exist_ok=True)
        path = core.unique_path(folder, core.safe_filename(r.name), ".magnet.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(r.magnet)
    except OSError as e:
        return {"error": f"Could not save the file: {e}"}
    with STATE.lock:
        STATE.saved.add(os.path.abspath(path))
    return {"path": path}


def api_open_folder(body):
    """Show a file this app saved in the system file manager (or just open Downloads)."""
    requested = os.path.abspath(str(body.get("path"))) if body.get("path") else ""
    with STATE.lock:
        target = requested if requested in STATE.saved and os.path.exists(requested) else ""
    folder = os.path.dirname(target) if target else downloads_dir()
    try:
        if sys.platform == "win32":
            if target:
                subprocess.Popen(["explorer", "/select,", target])
            else:
                os.startfile(folder)  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", "-R", target] if target else ["open", folder])
        else:
            shown = False
            if target and shutil.which("dbus-send"):
                try:
                    shown = subprocess.run(
                        ["dbus-send", "--session", "--print-reply", "--dest=org.freedesktop.FileManager1",
                         "/org/freedesktop/FileManager1", "org.freedesktop.FileManager1.ShowItems",
                         "array:string:" + "file://" + urllib.parse.quote(target), "string:"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4).returncode == 0
                except (OSError, subprocess.SubprocessError):
                    shown = False
            if not shown:
                subprocess.Popen(["xdg-open", folder], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as e:
        return {"error": f"Could not open the folder: {e}"}
    return {"ok": True}


def api_ping(_body):
    STATE.last_ping = time.time()
    STATE.bye_at = None
    return {"ok": True}


def api_bye(_body):
    STATE.bye_at = time.time() + BYE_GRACE
    return {"ok": True}


ROUTES = {
    "search": api_search,
    "more": api_more,
    "save": api_save,
    "open-folder": api_open_folder,
    "ping": api_ping,
    "bye": api_bye,
}


class Handler(BaseHTTPRequestHandler):
    server_version = "Torrentula"

    def log_message(self, *_args):
        pass  # keep the console quiet

    # Only answer requests addressed to this computer (blocks DNS rebinding).
    def _host_ok(self):
        return self.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def _send(self, code, body, content_type, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._host_ok():
            return self._send(403, b"Forbidden", "text/plain")
        path = urllib.parse.urlsplit(self.path).path
        if path == "/":
            try:
                with open(HTML_PATH, "r", encoding="utf-8") as f:
                    page = f.read().replace("__TOKEN__", TOKEN)
            except OSError:
                return self._send(500, b"Interface file is missing.", "text/plain")
            return self._send(200, page.encode("utf-8"), "text/html; charset=utf-8",
                              {"Content-Security-Policy":
                               "default-src 'self'; style-src 'self' 'unsafe-inline'; "
                               "script-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                               "connect-src 'self'; frame-ancestors 'none'"})
        if path == "/icon.png":
            try:
                with open(ICON_PATH, "rb") as f:
                    return self._send(200, f.read(), "image/png")
            except OSError:
                return self._send(404, b"", "image/png")
        self._send(404, b"Not found", "text/plain")

    def do_POST(self):
        if not self._host_ok():
            return self._send(403, b"Forbidden", "text/plain")
        parts = urllib.parse.urlsplit(self.path)
        if not parts.path.startswith("/api/"):
            return self._send(404, b"Not found", "text/plain")
        # sendBeacon cannot set headers, so the token may also come in the query string.
        supplied = self.headers.get("X-Token") or urllib.parse.parse_qs(parts.query).get("t", [""])[0]
        if not secrets.compare_digest(supplied, TOKEN):
            return self._send(403, b"Forbidden", "text/plain")
        handler = ROUTES.get(parts.path[len("/api/"):])
        if handler is None:
            return self._send(404, b"Not found", "text/plain")

        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length > MAX_BODY:
            return self._send(413, b"Too large", "text/plain")
        raw = self.rfile.read(length) if length else b""
        try:
            body = json.loads(raw.decode("utf-8")) if raw else {}
            if not isinstance(body, dict):
                body = {}
        except ValueError:
            body = {}

        try:
            payload = handler(body)
        except Exception as e:  # keep the window usable whatever goes wrong
            payload = {"error": str(e)}
        self._send(200, json.dumps(payload).encode("utf-8"), "application/json")


def find_app_browser():
    """A Chromium-based browser that can open a chromeless app window."""
    candidates = []
    if sys.platform == "win32":
        for env in ("PROGRAMFILES(X86)", "PROGRAMFILES", "LOCALAPPDATA"):
            base = os.environ.get(env)
            if not base:
                continue
            for rel in (r"Microsoft\Edge\Application\msedge.exe",
                        r"Google\Chrome\Application\chrome.exe",
                        r"BraveSoftware\Brave-Browser\Application\brave.exe"):
                candidates.append(os.path.join(base, rel))
    elif sys.platform == "darwin":
        for app in ("Google Chrome", "Microsoft Edge", "Brave Browser", "Chromium"):
            candidates.append(f"/Applications/{app}.app/Contents/MacOS/{app}")
    else:
        for name in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser",
                     "microsoft-edge", "microsoft-edge-stable", "brave-browser"):
            found = shutil.which(name)
            if found:
                candidates.append(found)
    for c in candidates:
        if os.path.exists(c):
            return c
    return None


def open_window(url, use_tab):
    if not use_tab:
        exe = find_app_browser()
        if exe:
            try:
                subprocess.Popen([exe, f"--app={url}", "--window-size=1060,780"],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return
            except OSError:
                pass
    webbrowser.open(url)


def watchdog():
    """Quit once the window has gone away."""
    while True:
        time.sleep(1)
        now = time.time()
        if STATE.bye_at and now > STATE.bye_at:
            os._exit(0)
        if STATE.last_ping is None:
            if now - STATE.started > IDLE_LIMIT:
                os._exit(0)
        elif now - STATE.last_ping > IDLE_LIMIT:
            os._exit(0)


def main():
    global PORT
    parser = argparse.ArgumentParser(description="Torrentula, graphical version.")
    parser.add_argument("--tab", action="store_true", help="open in a normal browser tab")
    parser.add_argument("--no-open", action="store_true", help="do not open a window; just print the address")
    parser.add_argument("--port", type=int, default=0, help="port to listen on (default: any free port)")
    args = parser.parse_args()

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.daemon_threads = True
    PORT = server.server_address[1]
    url = f"http://127.0.0.1:{PORT}/"
    print(f"Torrentula is running at {url}")

    threading.Thread(target=watchdog, daemon=True).start()
    if not args.no_open:
        open_window(url, args.tab)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback

        traceback.print_exc()
        sys.exit(1)
