#!/usr/bin/env python3
"""
torrentula.py

A simple terminal torrent search tool. Queries multiple public torrent
indexes in parallel, merges and ranks the results by seeder count, lets you
page through them, and then either copy the chosen magnet link to your
clipboard or save it as a text file in the magnetfiles folder, for use in
your own torrent client.

Intended for legal use: open-source software, Linux distros, and other
freely distributable files.

Usage:
    python torrentula.py "ubuntu 24.04 desktop"
    python torrentula.py -n 25 "debian iso"     # 25 results per page
    python torrentula.py                        # will prompt for a search term
"""

import argparse
import math
import os
import re
import shutil
import subprocess
import sys
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import List, Optional, Set, Tuple

import requests

# Windows consoles often default to a legacy codepage (cp1252/cp437) that
# can't print many characters that show up in torrent titles (accented
# letters, CJK text, symbols, etc.), which raises UnicodeEncodeError and
# crashes the script. Force UTF-8 output where possible; on older Python
# versions that don't support reconfigure(), just fall back silently.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

USER_AGENT = "Mozilla/5.0 (compatible; torrentula-cli/1.1)"
TIMEOUT = 12

# Name of each source that failed during the latest request, with the reason.
# The terminal UI ignores this; the GUI reads it to tell the person which
# source did not respond.
SOURCE_ERRORS = {}

# Knaben is queried one "page" of this many hits at a time. Extra pages are
# only fetched when you browse past the results already loaded.
KNABEN_PAGE_SIZE = 100
KNABEN_MAX_PAGES = 10  # hard cap: at most 1000 hits from Knaben per search

# Where saved magnet files go. Relative to the app itself (not the current
# working directory), so it lands in the same place regardless of where you
# run the tool from. When frozen into an .exe by PyInstaller, __file__ points
# into a temporary extraction folder that gets wiped on exit, so we use the
# actual .exe's location instead in that case.
if getattr(sys, "frozen", False):
    SCRIPT_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# The installed launchers set this so magnetfiles always lives in the install
# folder, whatever the current working directory is.
MAGNET_DIR = os.environ.get("TORRENTULA_MAGNET_DIR") or os.path.join(SCRIPT_DIR, "magnetfiles")


@dataclass
class Result:
    name: str
    seeders: int
    leechers: int
    size_bytes: int
    source: str
    magnet: str

    @property
    def key(self) -> str:
        """Identity used for de-duplication: the torrent's info-hash if we
        can find one, otherwise the normalised title."""
        m = re.search(r"btih(?::|%3A)([A-Za-z0-9]+)", self.magnet, re.IGNORECASE)
        if m:
            return m.group(1).lower()
        return re.sub(r"\s+", " ", self.name.strip().lower())


# --------------------------------------------------------------------------
# Source: apibay.org (The Pirate Bay's official JSON API)
# --------------------------------------------------------------------------
def search_apibay(query: str) -> List[Result]:
    url = "https://apibay.org/q.php"
    try:
        resp = requests.get(
            url,
            params={"q": query, "cat": 0},
            headers={"User-Agent": USER_AGENT},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        SOURCE_ERRORS["PirateBay"] = str(e)
        print(f"  [apibay] search failed: {e}", file=sys.stderr)
        return []

    results = []
    for item in data:
        # apibay returns a single dummy entry {"id": "0", "name": "No results returned"}
        info_hash = item.get("info_hash", "")
        if not info_hash or item.get("id") == "0" or set(info_hash) == {"0"}:
            continue
        name = item.get("name", "unknown")
        magnet = build_magnet(info_hash, name)
        try:
            seeders = int(item.get("seeders", 0))
            leechers = int(item.get("leechers", 0))
            size_bytes = int(item.get("size", 0))
        except (TypeError, ValueError):
            continue
        results.append(
            Result(
                name=name,
                seeders=seeders,
                leechers=leechers,
                size_bytes=size_bytes,
                source="PirateBay",
                magnet=magnet,
            )
        )
    return results


# --------------------------------------------------------------------------
# Source: knaben.org (meta-search across TPB, 1337x, Nyaa, YTS, and more)
# --------------------------------------------------------------------------
def search_knaben(query: str, offset: int = 0, size: int = KNABEN_PAGE_SIZE) -> Tuple[List[Result], int, bool]:
    """Fetch one page of Knaben results.

    Returns (results, raw_hit_count, ok). raw_hit_count is how many hits the
    API returned before we skipped any unusable ones, so the caller can tell
    when the last page has been reached. ok is False if the request failed.
    """
    url = "https://api.knaben.org/v1"
    payload = {
        "search_type": "100%",
        "search_field": "title",
        "query": query,
        "order_by": "seeders",
        "order_direction": "desc",
        "from": offset,
        "size": size,
        "hide_unsafe": True,
        "hide_xxx": True,
    }
    try:
        resp = requests.post(
            url,
            json=payload,
            headers={"User-Agent": USER_AGENT},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        SOURCE_ERRORS["Knaben"] = str(e)
        print(f"  [knaben] search failed: {e}", file=sys.stderr)
        return [], 0, False

    hits = data.get("hits") or []
    results = []
    for hit in hits:
        name = hit.get("title") or "unknown"
        magnet = hit.get("magnetUrl")
        if not magnet:
            info_hash = hit.get("hash")
            if not info_hash:
                continue  # no way to build a magnet link, skip
            magnet = build_magnet(info_hash, name)
        try:
            seeders = int(hit.get("seeders") or 0)
            leechers = int(hit.get("peers") or 0)
            size_bytes = int(hit.get("bytes") or 0)
        except (TypeError, ValueError):
            continue
        tracker = hit.get("tracker") or "Knaben"
        results.append(
            Result(
                name=name,
                seeders=seeders,
                leechers=leechers,
                size_bytes=size_bytes,
                source=tracker,
                magnet=magnet,
            )
        )
    return results, len(hits), True


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
DEFAULT_TRACKERS = [
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.tiny-vps.com:6969/announce",
]

_WINDOWS_RESERVED = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def build_magnet(info_hash: str, name: str) -> str:
    params = [("xt", f"urn:btih:{info_hash}"), ("dn", name)]
    magnet = "magnet:?" + urllib.parse.urlencode(params)
    for tr in DEFAULT_TRACKERS:
        magnet += "&tr=" + urllib.parse.quote(tr, safe="")
    return magnet


def human_size(num_bytes: int) -> str:
    size = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024:
            return f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}PB"


def safe_filename(name: str) -> str:
    cleaned = re.sub(r'[\\/*?:"<>|\x00-\x1f]', "_", name).strip()
    cleaned = cleaned[:150].rstrip(". ")  # Windows dislikes trailing dots/spaces
    if cleaned.split(".")[0].upper() in _WINDOWS_RESERVED:
        cleaned = "_" + cleaned
    return cleaned or "torrent"


def unique_path(directory: str, base: str, ext: str) -> str:
    """Return a path that doesn't clobber an existing file."""
    path = os.path.join(directory, base + ext)
    n = 2
    while os.path.exists(path):
        path = os.path.join(directory, f"{base} ({n}){ext}")
        n += 1
    return path


def copy_to_clipboard(text: str) -> bool:
    """Try pyperclip first, then fall back to common OS clipboard utilities."""
    try:
        import pyperclip  # optional dependency

        pyperclip.copy(text)
        return True
    except Exception:
        pass

    candidates = [
        ["pbcopy"],                                # macOS
        ["xclip", "-selection", "clipboard"],      # Linux (X11)
        ["xsel", "--clipboard", "--input"],        # Linux (X11, alt)
        ["wl-copy"],                               # Linux (Wayland)
        ["clip.exe"],                              # Windows / WSL
    ]
    for cmd in candidates:
        if not shutil.which(cmd[0]):
            continue
        try:
            subprocess.run(cmd, input=text.encode(), check=True)
            return True
        except Exception:
            continue
    return False


# --------------------------------------------------------------------------
# Search session (handles merging + loading further pages on demand)
# --------------------------------------------------------------------------
class SearchSession:
    def __init__(self, query: str):
        self.query = query
        self.results: List[Result] = []
        self._seen: Set[str] = set()
        self._knaben_offset = 0
        self._knaben_pages = 0
        self.exhausted = False  # True once there is nothing more to fetch

    def _add(self, new: List[Result]) -> int:
        """Append unseen results (best seeders first). Returns how many were added."""
        added = 0
        for r in sorted(new, key=lambda r: (r.seeders, r.leechers), reverse=True):
            if r.key in self._seen:
                continue
            self._seen.add(r.key)
            self.results.append(r)
            added += 1
        return added

    def _record_knaben_page(self, raw_count: int, ok: bool) -> None:
        if not ok:
            return
        self._knaben_offset += raw_count
        self._knaben_pages += 1
        if raw_count < KNABEN_PAGE_SIZE or self._knaben_pages >= KNABEN_MAX_PAGES:
            self.exhausted = True

    def load_initial(self) -> None:
        """Query both sources at the same time and merge the first batch."""
        with ThreadPoolExecutor(max_workers=2) as pool:
            f_apibay = pool.submit(search_apibay, self.query)
            f_knaben = pool.submit(search_knaben, self.query, 0, KNABEN_PAGE_SIZE)
            apibay_results = f_apibay.result()
            knaben_results, raw_count, ok = f_knaben.result()
        self._add(apibay_results + knaben_results)
        self._record_knaben_page(raw_count, ok)
        if not ok:
            # Knaben is down; PirateBay returns everything in one go, so
            # there is nothing further we could page through.
            self.exhausted = True

    def fetch_more(self) -> int:
        """Load the next Knaben page. Returns the number of new results."""
        if self.exhausted:
            return 0
        print("  loading more results...")
        # Keep going if a whole page turns out to be duplicates of what we have.
        while not self.exhausted:
            results, raw_count, ok = search_knaben(self.query, self._knaben_offset, KNABEN_PAGE_SIZE)
            if not ok:
                print("  Couldn't load more results right now. Try again in a moment.")
                return 0
            self._record_knaben_page(raw_count, ok)
            added = self._add(results)
            if added:
                return added
        return 0


# --------------------------------------------------------------------------
# Terminal UI
# --------------------------------------------------------------------------
def total_pages(session: SearchSession, page_size: int) -> int:
    return max(1, math.ceil(len(session.results) / page_size))


def print_page(session: SearchSession, page: int, page_size: int) -> None:
    results = session.results
    if not results:
        print("\nNo results found.")
        return
    pages = total_pages(session, page_size)
    start = page * page_size
    end = min(start + page_size, len(results))
    more = "+" if not session.exhausted else ""

    print(f"\nResults {start + 1}-{end} of {len(results)}{more}   (page {page + 1} of {pages}{more})")
    print(f"{'#':<4} {'S':>5} {'L':>5} {'Size':>9}  {'Source':<12} Name")
    print("-" * 100)
    for i in range(start, end):
        r = results[i]
        name = r.name if len(r.name) <= 60 else r.name[:57] + "..."
        print(f"{i + 1:<4} {r.seeders:>5} {r.leechers:>5} {human_size(r.size_bytes):>9}  {r.source[:12]:<12} {name}")


def go_to_page(session: SearchSession, target: int, page_size: int) -> int:
    """Return a valid page index near `target`, loading more results if needed."""
    while target >= total_pages(session, page_size) and not session.exhausted:
        if session.fetch_more() == 0:
            break
    return max(0, min(target, total_pages(session, page_size) - 1))


def handle_selection(r: Result) -> None:
    print(f"\nSelected: {r.name}")
    print(f"Seeders: {r.seeders}  Leechers: {r.leechers}  Size: {human_size(r.size_bytes)}  Source: {r.source}")
    while True:
        print("\nWhat would you like to do?")
        print("  [1] Copy magnet link to clipboard (recommended)")
        print("  [2] Save magnet link as a text file in the magnetfiles folder")
        print("  [3] Print the magnet link")
        print("  [4] Back to results")
        print("  [q] Quit")
        choice = input("> ").strip().lower()

        if choice == "1":
            if copy_to_clipboard(r.magnet):
                print("Magnet link copied to clipboard.")
                print('Paste it into your torrent client\'s "Add Link" / "Add Magnet Link" '
                      "dialog (NOT \"Add Torrent File\", which is for real .torrent files).")
            else:
                print("Couldn't find a clipboard tool (tried pyperclip, xclip, xsel, "
                      "wl-copy, pbcopy, clip.exe). Here's the link instead:\n")
                print(r.magnet)
        elif choice == "2":
            try:
                os.makedirs(MAGNET_DIR, exist_ok=True)
                path = unique_path(MAGNET_DIR, safe_filename(r.name), ".magnet.txt")
                with open(path, "w", encoding="utf-8") as f:
                    f.write(r.magnet)
            except OSError as e:
                print(f"Couldn't save the file: {e}")
                continue
            print(f"Saved to {path}")
            print('NOTE: this is a plain text file containing the magnet link, not a real '
                  '.torrent file. Open it in a text editor and copy the link, then use your '
                  'torrent client\'s "Add Link" / "Add Magnet Link" option, do NOT use '
                  '"Add Torrent File", which expects actual .torrent binary data and will error.')
        elif choice == "3":
            print("\n" + r.magnet)
        elif choice == "4":
            return
        elif choice == "q":
            sys.exit(0)
        else:
            print("Not a valid option.")


def browse(session: SearchSession, page_size: int) -> Optional[str]:
    """Interactive results browser.

    Returns "search" if the user wants a new search, or None to quit.
    """
    page = 0
    while True:
        print_page(session, page, page_size)
        if not session.results:
            return "search"

        print("\nEnter a result number to select it.")
        print("  [n] next page   [p] previous page   [g N] go to page N")
        print("  [s] new search  [q] quit")
        choice = input("> ").strip().lower()

        if choice == "q":
            return None
        elif choice == "s":
            return "search"
        elif choice in ("n", "next"):
            nxt = go_to_page(session, page + 1, page_size)
            if nxt == page:
                print("\nYou're already on the last page; no more results.")
            page = nxt
        elif choice in ("p", "prev", "previous"):
            if page == 0:
                print("\nYou're already on the first page.")
            else:
                page -= 1
        elif re.fullmatch(r"g\s*\d*", choice):
            digits = choice[1:].strip()
            if not digits:
                digits = input("Go to page: ").strip()
            if not digits.isdigit() or int(digits) < 1:
                print("Not a valid page number.")
                continue
            wanted = int(digits) - 1
            page = go_to_page(session, wanted, page_size)
            if page != wanted:
                print(f"\nOnly {total_pages(session, page_size)} page(s) available; showing the last one.")
        elif choice.isdigit() and 1 <= int(choice) <= len(session.results):
            handle_selection(session.results[int(choice) - 1])
        else:
            print("Not a valid choice.")


def ask_query(prompt: str = "Search term: ") -> str:
    return input(prompt).strip()


def main():
    parser = argparse.ArgumentParser(description="Search multiple torrent sites and rank by seeders.")
    parser.add_argument("query", nargs="?", help="Search term")
    parser.add_argument("-n", "--per-page", "--top", dest="per_page", type=int, default=15,
                        help="Number of results to show per page (default: 15)")
    args = parser.parse_args()
    if args.per_page < 1:
        parser.error("--per-page must be at least 1")

    query = args.query or ask_query()
    if not query:
        print("No search term given.")
        return

    while True:
        print(f"\nSearching for: {query!r}")
        print("  querying PirateBay (apibay) and Knaben (multi-site)...")
        session = SearchSession(query)
        session.load_initial()

        if not session.results:
            print("\nNo results found.")
            query = ask_query("\nTry another search term (or press Enter to quit): ")
            if not query:
                return
            continue

        if browse(session, args.per_page) is None:
            return
        query = ask_query()
        if not query:
            return


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nBye.")
    except Exception:
        import traceback

        traceback.print_exc()
        # If this was double-clicked on Windows instead of run from a
        # terminal, the window would otherwise close instantly and hide
        # the error above. Keep it open so it can be read/copied.
        if sys.platform == "win32":
            input("\nSomething went wrong (see error above). Press Enter to close...")
        sys.exit(1)
