#!/usr/bin/env bash
# Torrentula installer for Linux (run by Install-Linux.sh). No root needed.
#   app + its own private Python environment -> ~/.local/share/torrentula
#   `torrentula` command                       -> ~/.local/bin
#   application-menu entry                     -> ~/.local/share/applications
set -e

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="$(cd "$HERE/../app" && pwd)"
DATA="${XDG_DATA_HOME:-$HOME/.local/share}"
INSTALL="$DATA/torrentula"
BIN="$HOME/.local/bin"
MENU="$DATA/applications"

say()  { printf '%s\n' "$*"; }
fail() { printf '\n%s\n' "$*" >&2; exit 1; }

say ""
say "Installing Torrentula"
say "---------------------"

[ -f "$APP/torrentula.py" ] || fail "Couldn't find files/app/torrentula.py. Please extract the whole zip first, then run the installer again."

# 1. Python ---------------------------------------------------------------
say "[1/3] Looking for Python..."
PY=""
for c in python3 python; do
    if command -v "$c" >/dev/null 2>&1 && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
        PY="$(command -v "$c")"; break
    fi
done
if [ -z "$PY" ]; then
    hint="Install Python 3.8+ with your package manager, then run this again."
    if   command -v apt-get >/dev/null 2>&1; then hint="Install it with:  sudo apt install python3 python3-venv"
    elif command -v dnf     >/dev/null 2>&1; then hint="Install it with:  sudo dnf install python3"
    elif command -v pacman  >/dev/null 2>&1; then hint="Install it with:  sudo pacman -S python"
    elif command -v zypper  >/dev/null 2>&1; then hint="Install it with:  sudo zypper install python3"
    fi
    fail "Python 3.8 or newer wasn't found. $hint"
fi
say "      Using $PY"

# 2. Private environment --------------------------------------------------
say "[2/3] Setting up (a few seconds)..."
mkdir -p "$INSTALL/magnetfiles"
rm -rf "$INSTALL/venv"
if ! "$PY" -m venv "$INSTALL/venv" >/dev/null 2>&1; then
    rm -rf "$INSTALL/venv"
    hint=""
    command -v apt-get >/dev/null 2>&1 && hint=" On Debian/Ubuntu:  sudo apt install python3-venv"
    fail "Couldn't create a Python environment.$hint"
fi
"$INSTALL/venv/bin/python" -m pip install --disable-pip-version-check -q -r "$APP/requirements.txt" \
    || fail "Couldn't download the dependencies. Check your internet connection and try again."

cp "$APP/torrentula.py" "$APP/torrentula_gui.py" "$APP/torrentula_gui.html" "$APP/torrentula.png" "$INSTALL/"

# 3. Launcher + menu entry --------------------------------------------------
say "[3/3] Adding the 'torrentula' command and menu entry..."
cat > "$INSTALL/torrentula" <<LAUNCH
#!/usr/bin/env bash
export TORRENTULA_MAGNET_DIR="$INSTALL/magnetfiles"
exec "$INSTALL/venv/bin/python" "$INSTALL/torrentula.py" "\$@"
LAUNCH
chmod +x "$INSTALL/torrentula"

cat > "$INSTALL/torrentula-gui" <<LAUNCH
#!/usr/bin/env bash
export TORRENTULA_MAGNET_DIR="$INSTALL/magnetfiles"
exec "$INSTALL/venv/bin/python" "$INSTALL/torrentula_gui.py" "\$@"
LAUNCH
chmod +x "$INSTALL/torrentula-gui"

mkdir -p "$BIN" "$MENU"
ln -sf "$INSTALL/torrentula" "$BIN/torrentula"
ln -sf "$INSTALL/torrentula-gui" "$BIN/torrentula-gui"

cat > "$MENU/torrentula.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Torrentula
Comment=Search multiple torrent sites and rank results by seeders
Exec="$INSTALL/torrentula-gui"
Icon=$INSTALL/torrentula.png
Terminal=false
Categories=Network;FileTransfer;
DESKTOP

cat > "$MENU/torrentula-terminal.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Torrentula Terminal
Comment=Torrentula, text version
Exec="$INSTALL/torrentula"
Icon=$INSTALL/torrentula.png
Terminal=true
Categories=Network;FileTransfer;
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$MENU" >/dev/null 2>&1 || true

say ""
say "Done! Torrentula is installed."
say "  Open Torrentula from your applications menu, or run:  torrentula-gui"
say "  Prefer text? Run:  torrentula \"ubuntu 24.04\""
say "  The app saves magnet files to your Downloads folder."
say "  (The terminal version saves them in: $INSTALL/magnetfiles)"
case ":$PATH:" in
    *":$BIN:"*) ;;
    *) say ""
       say "  Note: $BIN isn't on your PATH yet, so the 'torrentula' command won't work"
       say "  until you log out and back in (the menu entry works right away)." ;;
esac
say ""
say "To uninstall: bash files/linux/uninstall.sh"
