<#
Torrentula installer for Windows (run by Install-Windows.bat).

One step does everything:
  1. finds Python (and installs it with winget if it's missing)
  2. builds Torrentula.exe in a throwaway temp folder
  3. copies it to %LOCALAPPDATA%\Programs\Torrentula
  4. adds a Start Menu shortcut and an entry under
     Settings > Apps > Installed apps

No administrator rights needed -- everything is per-user.
#>

$ErrorActionPreference = "Stop"

$here   = Split-Path -Parent $MyInvocation.MyCommand.Path   # ...\files\windows
$appDir = Join-Path (Split-Path -Parent $here) "app"        # ...\files\app

function Say($msg, $color = "White") { Write-Host $msg -ForegroundColor $color }
function Fail($msg) { Write-Host ""; Write-Host $msg -ForegroundColor Red; exit 1 }

# ---------------------------------------------------------------- Python ---
function Test-Python($exe, $pre) {
    try {
        $out = & $exe @pre -c "import sys; print(sys.executable if sys.version_info >= (3, 8) else '')" 2>$null
        if ($LASTEXITCODE -eq 0 -and $out) {
            $p = ("$out").Trim()
            if ($p -and (Test-Path $p)) { return $p }
        }
    } catch { }
    return $null
}

function Find-Python {
    $tries = @(
        @{ exe = "py";      pre = @("-3") },
        @{ exe = "python";  pre = @() },
        @{ exe = "python3"; pre = @() }
    )
    foreach ($t in $tries) {
        if (Get-Command $t.exe -ErrorAction SilentlyContinue) {
            $p = Test-Python $t.exe $t.pre
            if ($p) { return $p }
        }
    }
    # Fresh installs may not be on PATH yet for this window; look where they land.
    $roots = @("$env:LOCALAPPDATA\Programs\Python", "$env:ProgramFiles")
    foreach ($root in $roots) {
        $dirs = Get-ChildItem $root -Directory -Filter "Python3*" -ErrorAction SilentlyContinue | Sort-Object Name -Descending
        foreach ($d in $dirs) {
            $exe = Join-Path $d.FullName "python.exe"
            if (Test-Path $exe) {
                $p = Test-Python $exe @()
                if ($p) { return $p }
            }
        }
    }
    return $null
}

# Runs a program quietly, logging its output; returns the exit code.
function Run-Logged($exe, $argString, $log) {
    $p = Start-Process -FilePath $exe -ArgumentList $argString -Wait -PassThru -NoNewWindow `
         -RedirectStandardOutput $log -RedirectStandardError "$log.err"
    return $p.ExitCode
}

function Show-Log($log) {
    foreach ($f in @($log, "$log.err")) {
        if (Test-Path $f) { Get-Content $f -Tail 25 | ForEach-Object { Write-Host "    $_" -ForegroundColor DarkGray } }
    }
}

Say ""
Say "Installing Torrentula" "Cyan"
Say "---------------------" "Cyan"

if (-not (Test-Path (Join-Path $appDir "torrentula.py"))) {
    Fail "Couldn't find files\app\torrentula.py. Please extract the whole zip first, then run the installer again."
}

Say "[1/4] Looking for Python..."
$python = Find-Python
if (-not $python) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Say "      Python isn't installed. Installing it now (one-time, no admin needed)..."
        try {
            & winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
        } catch { }
        $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [Environment]::GetEnvironmentVariable("Path", "User")
        $python = Find-Python
    }
}
if (-not $python) {
    Fail ("Python 3.8 or newer is needed (only while installing) and I couldn't set it up automatically.`n" +
          "Install it from https://www.python.org/downloads/ (tick 'Add python.exe to PATH'), then run Install-Windows.bat again.")
}
Say "      Using $python" "DarkGray"

# --------------------------------------------------------------- Build ---
$work = Join-Path $env:TEMP ("torrentula-build-" + [guid]::NewGuid().ToString("N").Substring(0, 8))
New-Item -ItemType Directory -Force -Path $work | Out-Null
$exeSource = Join-Path $work "dist\Torrentula.exe"
$cliSource = Join-Path $work "dist\TorrentulaTerminal.exe"

try {
    Say "[2/4] Preparing the build (about a minute)..."
    $log = Join-Path $work "venv.log"
    if ((Run-Logged $python "-m venv `"$work\venv`"" $log) -ne 0) { Show-Log $log; Fail "Couldn't create the temporary build environment." }
    $venvPy = Join-Path $work "venv\Scripts\python.exe"

    $log = Join-Path $work "pip.log"
    $pipArgs = "-m pip install --disable-pip-version-check -q -r `"$appDir\requirements.txt`" pyinstaller pyinstaller-hooks-contrib"
    if ((Run-Logged $venvPy $pipArgs $log) -ne 0) { Show-Log $log; Fail "Couldn't download the build tools. Check your internet connection and try again." }

    Say "[3/4] Building the app..."
    # Torrentula.exe is the windowed app; TorrentulaTerminal.exe is the text version.
    $log = Join-Path $work "build-gui.log"
    $guiArgs = "-m PyInstaller --onefile --noconsole --name Torrentula --icon `"$appDir\torrentula.ico`" " +
               "--add-data `"$appDir\torrentula_gui.html;.`" --add-data `"$appDir\torrentula.png;.`" " +
               "--distpath `"$work\dist`" --workpath `"$work\build-gui`" --specpath `"$work`" --clean --noconfirm `"$appDir\torrentula_gui.py`""
    if ((Run-Logged $venvPy $guiArgs $log) -ne 0 -or -not (Test-Path $exeSource)) { Show-Log $log; Fail "The build failed (details above)." }

    $log = Join-Path $work "build-cli.log"
    $cliArgs = "-m PyInstaller --onefile --console --name TorrentulaTerminal --icon `"$appDir\torrentula.ico`" " +
               "--distpath `"$work\dist`" --workpath `"$work\build-cli`" --specpath `"$work`" --clean --noconfirm `"$appDir\torrentula.py`""
    if ((Run-Logged $venvPy $cliArgs $log) -ne 0 -or -not (Test-Path $cliSource)) { Show-Log $log; Fail "The build failed (details above)." }

    # ------------------------------------------------------------- Install ---
    Say "[4/4] Installing..."
    $installDir = Join-Path $env:LOCALAPPDATA "Programs\Torrentula"
    New-Item -ItemType Directory -Force -Path $installDir | Out-Null
    New-Item -ItemType Directory -Force -Path (Join-Path $installDir "magnetfiles") | Out-Null

    # Clean up a previous install under the old name (TorrentSearch), keeping saved magnets.
    $oldDir = Join-Path $env:LOCALAPPDATA "Programs\TorrentSearch"
    if (Test-Path $oldDir) {
        $oldMagnets = Join-Path $oldDir "magnetfiles"
        if (Test-Path $oldMagnets) {
            Copy-Item (Join-Path $oldMagnets "*") (Join-Path $installDir "magnetfiles") -Force -ErrorAction SilentlyContinue
        }
        Remove-Item $oldDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    Remove-Item (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Torrent Search.lnk") -Force -ErrorAction SilentlyContinue
    Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\TorrentSearch" -Recurse -Force -ErrorAction SilentlyContinue

    $exeDest = Join-Path $installDir "Torrentula.exe"
    try {
        Copy-Item $exeSource $exeDest -Force
        Copy-Item $cliSource (Join-Path $installDir "TorrentulaTerminal.exe") -Force
    } catch {
        Fail "Couldn't replace Torrentula.exe - is it still open? Close it and run the installer again."
    }
    Copy-Item (Join-Path $here "uninstall.ps1") (Join-Path $installDir "uninstall.ps1") -Force

    # Start Menu shortcut
    $shortcutPath = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Torrentula.lnk"
    $wsh = New-Object -ComObject WScript.Shell
    $shortcut = $wsh.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $exeDest
    $shortcut.WorkingDirectory = $installDir
    $shortcut.IconLocation = $exeDest
    $shortcut.Description = "Search multiple torrent sites and rank results by seeders"
    $shortcut.Save()

    $termShortcut = $wsh.CreateShortcut((Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Torrentula Terminal.lnk"))
    $termShortcut.TargetPath = Join-Path $installDir "TorrentulaTerminal.exe"
    $termShortcut.WorkingDirectory = $installDir
    $termShortcut.IconLocation = $exeDest
    $termShortcut.Description = "Torrentula, text version"
    $termShortcut.Save()

    # Settings > Apps > Installed apps entry
    $key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Torrentula"
    New-Item -Path $key -Force | Out-Null
    Set-ItemProperty -Path $key -Name "DisplayName"     -Value "Torrentula"
    Set-ItemProperty -Path $key -Name "DisplayIcon"     -Value $exeDest
    Set-ItemProperty -Path $key -Name "DisplayVersion"  -Value "1.1.0"
    Set-ItemProperty -Path $key -Name "Publisher"       -Value "Local build"
    Set-ItemProperty -Path $key -Name "UninstallString" -Value "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$installDir\uninstall.ps1`""
    Set-ItemProperty -Path $key -Name "InstallLocation" -Value $installDir
    Set-ItemProperty -Path $key -Name "NoModify" -Value 1 -Type DWord
    Set-ItemProperty -Path $key -Name "NoRepair" -Value 1 -Type DWord
}
finally {
    Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
}

Say ""
Say "Done! Torrentula is installed." "Green"
Say "  Open it from the Start Menu (search for 'Torrentula')."
Say "  A text-only version is there too, named 'Torrentula Terminal'."
Say "  The app saves magnet files to your Downloads folder."
Say "  (The terminal version saves them in: $installDir\magnetfiles)"
Say ""
Say "To uninstall: Settings > Apps > Installed apps > Torrentula,"
Say "or run files\windows\Uninstall.bat"
Say ""
Say "If Windows SmartScreen warns you on first launch, that's normal for a locally built app:" "DarkGray"
Say "click 'More info' > 'Run anyway'." "DarkGray"
