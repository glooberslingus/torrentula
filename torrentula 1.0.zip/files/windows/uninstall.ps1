<#
Uninstalls Torrentula for the current user. Safe to run from anywhere:
the installer also copies this file next to the installed exe, and
Settings > Apps > Installed apps > Torrentula > Uninstall runs that copy.

Any magnet files you saved are KEPT.
#>

$ErrorActionPreference = "SilentlyContinue"
$installDir = Join-Path $env:LOCALAPPDATA "Programs\Torrentula"

if (-not (Test-Path $installDir)) {
    Write-Host "Torrentula doesn't appear to be installed."
}

Get-Process -Name "Torrentula", "TorrentulaTerminal" | Stop-Process -Force
Remove-Item (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Torrentula.lnk") -Force
Remove-Item (Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Torrentula Terminal.lnk") -Force
Remove-Item "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Torrentula" -Recurse -Force
Write-Host "Torrentula has been uninstalled."

# This script may be running from inside $installDir, so it can't delete its
# own file or folder while running. Hand the final cleanup to a short detached
# process. The magnetfiles folder is only removed if it's empty.
$safeDir = $installDir -replace "'", "''"
$cleanupCommand = "Start-Sleep -Seconds 1; " +
    "Remove-Item -Force '$safeDir\Torrentula.exe', '$safeDir\TorrentulaTerminal.exe', '$safeDir\uninstall.ps1'; " +
    "if (-not (Get-ChildItem -Force '$safeDir\magnetfiles')) { Remove-Item -Force '$safeDir\magnetfiles' }; " +
    "if (-not (Get-ChildItem -Force '$safeDir')) { Remove-Item -Force '$safeDir' }"
Start-Process -FilePath "powershell.exe" -ArgumentList @("-NoProfile", "-WindowStyle", "Hidden", "-Command", $cleanupCommand) -WindowStyle Hidden

if (Test-Path "$installDir\magnetfiles\*") {
    Write-Host "Your saved magnet files were left in: $installDir\magnetfiles"
}
