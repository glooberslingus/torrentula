@echo off
title Torrentula installer
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0files\windows\install.ps1"
echo.
pause
