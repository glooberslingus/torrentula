#!/usr/bin/env bash
# Torrentula installer for macOS. Double-click this file (or run: bash Install-macOS.command)
cd "$(dirname "$0")" || exit 1
bash files/macos/install.sh
status=$?
echo
read -r -p "Press Enter to close..." _ || true
exit $status
