#!/usr/bin/env bash
# Torrentula installer for Linux. Run:  bash Install-Linux.sh
cd "$(dirname "$0")" || exit 1
bash files/linux/install.sh
status=$?
echo
read -r -p "Press Enter to close..." _ || true
exit $status
